param([string]$GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Command - Modern Operations')
$ErrorActionPreference = 'Stop'
if (Get-Process Command -ErrorAction SilentlyContinue) { throw 'Close Command before restoring.' }
$GamePath = (Resolve-Path -LiteralPath $GamePath).Path
$mod = Join-Path $GamePath 'CMO-Korean'
$entries = Get-Content -LiteralPath "$mod\manifest.json" -Raw | ConvertFrom-Json
foreach ($entry in $entries) {
  $dest = [IO.Path]::GetFullPath((Join-Path $GamePath $entry.Path))
  if (!$dest.StartsWith($GamePath.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)) { throw 'Invalid manifest path.' }
  if ((Get-FileHash -LiteralPath $dest).Hash -ne $entry.InstalledHash) { throw "File changed since installation: $($entry.Path). Refusing to overwrite newer data." }
  if ($entry.Existed -and (Get-FileHash -LiteralPath "$mod\backup\$($entry.Backup)").Hash -ne $entry.OriginalHash) { throw 'Backup integrity check failed.' }
}
$launcherSettings=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Command Modern Operations\Launcher\LauncherSettings.Config'
if(Test-Path -LiteralPath $launcherSettings) {
  [xml]$launcherConfig=Get-Content -LiteralPath $launcherSettings -Raw
  $language=$launcherConfig.configuration.appSettings.add | Where-Object key -eq 'Language'
  if($language -and $language.value -eq 'Korean') {
    Copy-Item -LiteralPath $launcherSettings -Destination "$mod\backup\launcher-before-restore.config" -Force
    $previous='English'
    if(Test-Path -LiteralPath "$mod\launcher-language.json") {
      $savedLanguage=(Get-Content -LiteralPath "$mod\launcher-language.json" -Raw | ConvertFrom-Json).OriginalLanguage
      if($savedLanguage -and $savedLanguage -ne 'Korean'){$previous=$savedLanguage}
    }
    $language.value=$previous;$launcherConfig.Save($launcherSettings)
  }
}
foreach ($entry in $entries) {
  $dest = Join-Path $GamePath $entry.Path
  if ($entry.Existed) { Copy-Item -LiteralPath "$mod\backup\$($entry.Backup)" -Destination $dest -Force }
  else { Remove-Item -LiteralPath $dest }
}
Move-Item -LiteralPath "$mod\manifest.json" -Destination "$mod\restored-manifest.json" -Force
Write-Host 'Original files restored. Backups retained in CMO-Korean\backup.'

﻿using System;
using System.IO;
using System.Drawing;
using System.Drawing.Imaging;
using System.Drawing.Text;
using System.Collections.Generic;
public static class KoreanButtonImages {
 public static readonly string[] Names={"Auto_Engage_Target","Manually_Engage_Target","Plot_Course","Throttle_Altitude","Formation_Editor","Magazines","Aircraft_Operations","Boat_Operations","Mount_Weapons","Sensors","Systems_Damage","Unit-Group_Doctrine","Mission_Editor"};
 static readonly string[] Labels={"자동 공격","수동 공격","항로 설정","속도·고도","진형 편집","탄약고","항공 작전","입출항 작전","장착대·무장","센서","장비·피해","교리·교전규칙","임무 편집"};
 static readonly string[] Keys={"F1","Shift+F1","F3","F2","F4","F5","F6","F7","F8","F9","F10","Ctrl+F9","F11"};
 public static void Generate(string game,string output){
  Directory.CreateDirectory(output);
  for(int i=0;i<Names.Length;i++){
   string file="Btn_"+Names[i]+".png";
   using(var source=new Bitmap(Path.Combine(game,"Symbols","Menu",file)))
   using(var bitmap=new Bitmap(source)){
    if(source.Width!=114||source.Height!=32)throw new InvalidDataException("Unexpected button dimensions: "+file+" "+source.Width+"x"+source.Height);
    // x=111 is the clear inner-right background column in all 13 assets.
    // Attack labels begin at x=35, unlike most other labels. Preserve the
    // original icon to its left, and the complete outer border.
    for(int y=3;y<29;y++)for(int x=35;x<111;x++)
      bitmap.SetPixel(x,y,source.GetPixel(111,y));
    using(var g=Graphics.FromImage(bitmap))
    using(var font=new Font("Malgun Gothic",10,FontStyle.Regular,GraphicsUnit.Pixel))
    using(var keyFont=new Font("Segoe UI",9,FontStyle.Regular,GraphicsUnit.Pixel))
    using(var brush=new SolidBrush(Color.FromArgb(244,244,237)))
    using(var format=new StringFormat()){
     g.SetClip(new Rectangle(35,3,76,26));
     g.TextRenderingHint=TextRenderingHint.AntiAliasGridFit;
     format.Alignment=StringAlignment.Center;format.LineAlignment=StringAlignment.Center;
     format.FormatFlags=StringFormatFlags.NoWrap;
     g.DrawString(Labels[i],font,brush,new RectangleF(35,3,76,14),format);
     g.DrawString(Keys[i],keyFont,brush,new RectangleF(35,17,76,12),format);
    }
    bitmap.Save(Path.Combine(output,file),ImageFormat.Png);
   }
  }
 }
}

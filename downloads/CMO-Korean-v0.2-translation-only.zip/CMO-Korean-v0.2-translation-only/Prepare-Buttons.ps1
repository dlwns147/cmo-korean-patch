﻿param([Parameter(Mandatory=$true)][string]$GamePath)
$ErrorActionPreference='Stop'
if($PSVersionTable.PSEdition -eq 'Core'){
 & powershell.exe -NoProfile -ExecutionPolicy Bypass -File $PSCommandPath -GamePath $GamePath
 if($LASTEXITCODE -ne 0){throw 'Button generation failed'}
 return
}
$GamePath=(Resolve-Path -LiteralPath $GamePath).Path
$modRoot=[IO.Path]::GetFullPath((Join-Path $GamePath 'CMO-Korean'))
function Check-ButtonPath([string]$Path){if(![IO.Path]::GetFullPath($Path).StartsWith($modRoot.TrimEnd('\')+'\',[StringComparison]::OrdinalIgnoreCase)){throw 'Invalid button cache path'}}
Add-Type -AssemblyName System.Drawing
if(-not ('KoreanButtonImages' -as [type])){Add-Type -Path "$PSScriptRoot\ButtonImages.cs" -ReferencedAssemblies System.Drawing}
$target=Join-Path $GamePath 'CMO-Korean\buttons-original-ko-v1'
# Generate all images before replacing the cache. Never change game originals.
$staging=Join-Path $GamePath ('CMO-Korean\buttons-staging-'+[Guid]::NewGuid().ToString('N'))
Check-ButtonPath $target
Check-ButtonPath $staging
[KoreanButtonImages]::Generate($GamePath,$staging)
if(Test-Path -LiteralPath $target){
 $backup=Join-Path $GamePath ('CMO-Korean\buttons-backup-'+[Guid]::NewGuid().ToString('N'))
 Check-ButtonPath $backup
 Move-Item -LiteralPath $target -Destination $backup
 try {Move-Item -LiteralPath $staging -Destination $target}
 catch {Move-Item -LiteralPath $backup -Destination $target;throw}
}else {Move-Item -LiteralPath $staging -Destination $target}
Write-Host 'Prepared 13 Korean button images from the local game assets.'

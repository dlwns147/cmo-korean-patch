﻿param([string]$GamePath = 'C:\Program Files (x86)\Steam\steamapps\common\Command - Modern Operations')
$ErrorActionPreference = 'Stop'
if(Test-Path -LiteralPath "$PSScriptRoot\translation-build-in-progress.txt"){throw '시나리오 번역 파일을 생성 중입니다. 작업 완료 안내 후 설치해 주세요.'}
if(!(Test-Path -LiteralPath "$PSScriptRoot\scenario-ko.b64.tsv")){throw '시나리오 번역 사전이 없습니다. 설치를 중단했습니다.'}
$GamePath = (Resolve-Path -LiteralPath $GamePath).Path
if (Get-Process Command -ErrorAction SilentlyContinue) { throw 'Close Command before installing.' }
$expected = (Get-Content -LiteralPath "$PSScriptRoot\game-sha256.txt").Trim()
if ((Get-FileHash -LiteralPath "$GamePath\Command.exe" -Algorithm SHA256).Hash -ne $expected) { throw 'Game build differs from the tested build. Installation stopped.' }
foreach ($required in @('CMOKorean.dll','0Harmony.dll','ko.tsv','scenario-ko.b64.tsv','map-ko.tsv','map-points.tsv','Restore.ps1','payload')) {
  if (!(Test-Path -LiteralPath (Join-Path $PSScriptRoot $required))) { throw "Package incomplete: $required" }
}
$mod = Join-Path $GamePath 'CMO-Korean' 
if (Test-Path -LiteralPath "$mod\manifest.json") { throw 'Already installed. Run Restore.ps1 before reinstalling.' }
if (Test-Path -LiteralPath "$GamePath\CMOKorean.dll") { throw 'CMOKorean.dll already exists; refusing to replace an unmanaged file.' }
if (Test-Path -LiteralPath "$GamePath\0Harmony.dll") { throw '0Harmony.dll already exists; refusing to replace another mod dependency.' }
[xml]$config = Get-Content -LiteralPath "$GamePath\Command.exe.config"
if ($config.configuration.runtime.appDomainManagerAssembly -or $config.configuration.runtime.appDomainManagerType) { throw 'Another AppDomain manager is configured. Installation stopped.' }
New-Item -ItemType Directory -Force "$mod\backup" | Out-Null
Copy-Item -LiteralPath "$PSScriptRoot\ko.tsv" -Destination "$mod\ko.tsv"
Copy-Item -LiteralPath "$PSScriptRoot\scenario-ko.b64.tsv" -Destination "$mod\scenario-ko.b64.tsv"
Copy-Item -LiteralPath "$PSScriptRoot\map-ko.tsv" -Destination "$mod\map-ko.tsv"
Copy-Item -LiteralPath "$PSScriptRoot\map-points.tsv" -Destination "$mod\map-points.tsv"
$entries = New-Object System.Collections.Generic.List[object]
$targets = @('Command.exe.config','CMOKorean.dll','0Harmony.dll')
$payload = Join-Path $PSScriptRoot 'payload'
$payloadFiles=@(Get-ChildItem -LiteralPath $payload -File -Recurse)
$targets += $payloadFiles | ForEach-Object { $_.FullName.Substring($payload.Length+1) }
foreach ($rel in $targets) {
  $dest = Join-Path $GamePath $rel
  $exists = Test-Path -LiteralPath $dest
  if (!$exists -and $rel -notin @('CMOKorean.dll','0Harmony.dll','Launcher\Localization\stringsKorean.resx')) { throw "Required file missing: $rel" }
  $backupName = '{0:D3}.bak' -f $entries.Count
  if ($exists) { Copy-Item -LiteralPath $dest -Destination "$mod\backup\$backupName" }
  $entries.Add([pscustomobject]@{Path=$rel;Existed=$exists;Backup=$backupName;OriginalHash=$(if($exists){(Get-FileHash -LiteralPath $dest).Hash}else{''});InstalledHash=''})
}
try {
  Copy-Item -LiteralPath "$PSScriptRoot\CMOKorean.dll" -Destination "$GamePath\CMOKorean.dll"
  Copy-Item -LiteralPath "$PSScriptRoot\0Harmony.dll" -Destination "$GamePath\0Harmony.dll"
  foreach ($name in @('appDomainManagerAssembly','appDomainManagerType')) {
    $element = $config.CreateElement($name)
    $value = if ($name -eq 'appDomainManagerAssembly') { 'CMOKorean, Version=0.0.0.0, Culture=neutral, PublicKeyToken=null' } else { 'CMOKorean.Manager' }
    $element.SetAttribute('value',$value)
    [void]$config.configuration.runtime.AppendChild($element)
  }
  $config.Save("$GamePath\Command.exe.config")
  $payloadFiles | ForEach-Object { Copy-Item -LiteralPath $_.FullName -Destination (Join-Path $GamePath $_.FullName.Substring($payload.Length+1)) }
  foreach ($entry in $entries) { $entry.InstalledHash = (Get-FileHash -LiteralPath (Join-Path $GamePath $entry.Path)).Hash }
  $entries | ConvertTo-Json -Depth 4 | Set-Content -LiteralPath "$mod\manifest.json" -Encoding UTF8
  Copy-Item -LiteralPath "$PSScriptRoot\Restore.ps1" -Destination "$mod\Restore.ps1"
  $launcherSettings=Join-Path ([Environment]::GetFolderPath('MyDocuments')) 'My Games\Command Modern Operations\Launcher\LauncherSettings.Config'
  if(Test-Path -LiteralPath $launcherSettings) {
    [xml]$launcherConfig=Get-Content -LiteralPath $launcherSettings -Raw
    $language=$launcherConfig.configuration.appSettings.add | Where-Object key -eq 'Language'
    if($language) {
      $previous=if($language.value -eq 'Korean'){'English'}else{$language.value}
      @{OriginalLanguage=$previous} | ConvertTo-Json | Set-Content -LiteralPath "$mod\launcher-language.json" -Encoding UTF8
      Copy-Item -LiteralPath $launcherSettings -Destination "$mod\backup\launcher-before-install.config" -Force
      $language.value='Korean';$launcherConfig.Save($launcherSettings)
    }
  }
  Write-Host 'Installed CMO Korean 0.2. Start Command normally.'
} catch {
  foreach ($entry in $entries) {
    $dest = Join-Path $GamePath $entry.Path
    if ($entry.Existed) { Copy-Item -LiteralPath "$mod\backup\$($entry.Backup)" -Destination $dest -Force }
    elseif (Test-Path -LiteralPath $dest) { Remove-Item -LiteralPath $dest }
  }
  throw
}
